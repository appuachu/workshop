#! /bin/bash 

for_loo()
{
for rec in fcrackzip ;do
sudo apt-get install $rec
done
}
#main 
for_loo