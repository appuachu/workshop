# zipcracker
It is simple shell script command to crack the password of a zipfile.

<h1>Installation</h1>
$ git clone https://github.com/appuachu/zipcracker.git<br>
$ cd zipcracker<br>
$ chmod +x *<br>
$ bash install.sh<br>
$ bash zipcrack.sh
