<?php
include(__DIR__ . "/../php/result.php");
